package moduledistributionsystem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** Students, stored in the MySQL table `students`. */
public class StudentStore {

    
    private static final String COLS =
            "student_id, last_name, first_name, course, section, student_pass";

    private static Student read(ResultSet rs) throws SQLException {
    return new Student(rs.getString("student_id"), rs.getString("last_name"),
            rs.getString("first_name"), rs.getString("course"),
            rs.getString("section"), rs.getString("student_pass"));
}


    /** Creates the account. Returns the student, or null if it failed (e.g. ID already used). */
    public static Student add(String studentId, String lastName, String firstName,
                              String course, String section, String password) {
        String sql = "INSERT INTO students (" + COLS + ") VALUES (?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, studentId);
            ps.setString(2, lastName);
            ps.setString(3, firstName);
            ps.setString(4, course);
            ps.setString(5, section);
            ps.setString(6, password);
            ps.executeUpdate();
            return new Student(studentId, lastName, firstName, course, section, password);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public static List<Student> all() {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT " + COLS + " FROM students ORDER BY student_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(read(rs));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return list;
    }

    public static Student find(String studentId) {
        String sql = "SELECT " + COLS + " FROM students WHERE student_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return read(rs);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public static boolean exists(String studentId) { return find(studentId) != null; }

    /** For the login screen: returns the student if ID + password match, otherwise null. */
    public static Student login(String studentId, String password) {
        String sql = "SELECT " + COLS + " FROM students WHERE student_id = ? AND student_pass = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, studentId);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return read(rs);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    /** Profile update. The ID can never be changed. */
    public static void update(String studentId, String lastName, String course, String section) {
        String sql = "UPDATE students SET last_name=?, course=?, section=? WHERE student_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, lastName);
            ps.setString(2, course);
            ps.setString(3, section);
            ps.setString(4, studentId);
            ps.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /** Same, but also updates the first name. */
    public static void update(String studentId, String lastName, String firstName,
                              String course, String section) {
        String sql = "UPDATE students SET last_name=?, first_name=?, course=?, section=? WHERE student_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, lastName);
            ps.setString(2, firstName);
            ps.setString(3, course);
            ps.setString(4, section);
            ps.setString(5, studentId);
            ps.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /** Deletes the account (its reservations and notifications are deleted with it). */
    public static boolean delete(String studentId) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM students WHERE student_id = ?")) {
            ps.setString(1, studentId);
            return ps.executeUpdate() > 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
}