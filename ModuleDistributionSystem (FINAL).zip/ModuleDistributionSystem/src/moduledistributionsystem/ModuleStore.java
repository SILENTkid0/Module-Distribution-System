package moduledistributionsystem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Modules, stored in the MySQL table `modules`.
 */
public class ModuleStore {

    public static class ModuleData {

        private String id, name, code;
        private int yearLevel = 1, semester = 1;
        private boolean available;

        public ModuleData(String id, String name, String code, boolean available) {
            this.id = id;
            this.name = name;
            this.code = code;
            this.available = available;
        }

        public ModuleData(String id, String name, String code, int yearLevel, int semester,
                boolean available) {
            this(id, name, code, available);
            setYearLevel(yearLevel);
            setSemester(semester);
        }

        public String getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getCode() {
            return code;
        }

        public int getYearLevel() {
            return yearLevel;
        }

        public int getSemester() {
            return semester;
        }

        public boolean isAvailable() {
            return available;
        }

        public void setName(String name) {
            if (name == null || name.trim().isEmpty()) {
                throw new IllegalArgumentException("Module name is required");
            }
            this.name = name.trim();
        }

        public void setYearLevel(int y) {
            if (y < 1 || y > 4) {
                throw new IllegalArgumentException("Year level must be 1 to 4");
            }
            this.yearLevel = y;
        }

        public void setSemester(int s) {
            if (s < 1 || s > 2) {
                throw new IllegalArgumentException("Semester must be 1 or 2");
            }
            this.semester = s;
        }

        public void setAvailable(boolean available) {
            this.available = available;
        }

        /**
         * "1st Year" ... "4th Year" (same labels as the combo boxes)
         */
        public String yearLabel() {
            return ModuleStore.yearLabel(yearLevel);
        }

        /**
         * "1st Sem" / "2nd Sem"
         */
        public String semLabel() {
            return ModuleStore.semLabel(semester);
        }
    }

    public static String yearLabel(int y) {
        String[] t = {"1st Year", "2nd Year", "3rd Year", "4th Year"};
        return (y >= 1 && y <= 4) ? t[y - 1] : String.valueOf(y);
    }

    public static String semLabel(int s) {
        return s == 1 ? "1st Sem" : s == 2 ? "2nd Sem" : String.valueOf(s);
    }

    public static List<ModuleData> all() {
        List<ModuleData> list = new ArrayList<>();
        String sql = "SELECT module_id, module_name, subject_code, year_level, semester, available "
                + "FROM modules ORDER BY module_id";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new ModuleData(rs.getString(1), rs.getString(2), rs.getString(3),
                        rs.getInt(4), rs.getInt(5), rs.getBoolean(6)));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return list;
    }

    /**
     * Old signature: changes name, code and status only (year / sem untouched).
     */
    public static void update(String id, String name, String code, boolean available) {
        String sql = "UPDATE modules SET module_name=?, subject_code=?, available=? WHERE module_id=?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, code);
            ps.setBoolean(3, available);
            ps.setString(4, id);
            ps.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void update(String id, String name, String code, int yearLevel, int semester,
            boolean available) {
        String sql = "UPDATE modules SET module_name=?, subject_code=?, year_level=?, semester=?, "
                + "available=? WHERE module_id=?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, code);
            ps.setInt(3, yearLevel);
            ps.setInt(4, semester);
            ps.setBoolean(5, available);
            ps.setString(6, id);
            ps.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Returns false if the module could not be deleted (for example it is
     * already reserved).
     */
    public static boolean delete(String id) {
        String sql = "DELETE FROM modules WHERE module_id=?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    /**
     * Old signature: new module as 1st Year / 1st Sem.
     */
    public static void add(String id, String name, String code, boolean available) {
        add(id, name, code, 1, 1, available);
    }

    public static void add(String id, String name, String code, int yearLevel, int semester,
            boolean available) {
        String sql = "INSERT INTO modules (module_id, module_name, subject_code, year_level, semester, "
                + "available) VALUES (?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, id);
            ps.setString(2, name);
            ps.setString(3, code);
            ps.setInt(4, yearLevel);
            ps.setInt(5, semester);
            ps.setBoolean(6, available);
            ps.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
