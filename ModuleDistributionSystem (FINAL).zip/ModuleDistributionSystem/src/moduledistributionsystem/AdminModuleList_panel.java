package moduledistributionsystem;

import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;


/**
 *
 * @author Ron Ethan
 */
public class AdminModuleList_panel extends javax.swing.JPanel {

    /**
     * Creates new form AdminModuleList_panel
     */
    private static final String AVAILABLE = "Available", UNAVAILABLE = "Unavailable";

public AdminModuleList_panel() {
    initComponents();

    // table: Module ID is read-only, the other columns can be edited
    tblModules.setModel(new DefaultTableModel(
            new String[]{"Module ID", "Module Name", "Subject Code", "Status"}, 0) {
        @Override public boolean isCellEditable(int row, int col) { return col != 0; }
    });
    tblModules.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

    // Status column becomes a dropdown: Available / Unavailable
    JComboBox<String> status = new JComboBox<>(new String[]{AVAILABLE, UNAVAILABLE});
    tblModules.getColumnModel().getColumn(3).setCellEditor(new DefaultCellEditor(status));

    // table header colors
    tblModules.getTableHeader().setBackground(new java.awt.Color(0x202020));
    tblModules.getTableHeader().setForeground(new java.awt.Color(0x161616));
    tblModules.getTableHeader().setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14));

    loadModules();

    // search while typing
    txtSearch.getDocument().addDocumentListener(new DocumentListener() {
        public void insertUpdate(DocumentEvent e)  { loadModules(); }
        public void removeUpdate(DocumentEvent e)  { loadModules(); }
        public void changedUpdate(DocumentEvent e) { loadModules(); }
    });
    
    cmb_year.addActionListener(e -> loadModules());
    cmb_sem.addActionListener(e -> loadModules());

    btnUpdate.addActionListener(e -> updateModules());
    btnDelete.addActionListener(e -> deleteModule());
    

    // reload every time the admin opens this screen
    addComponentListener(new java.awt.event.ComponentAdapter() {
        @Override public void componentShown(java.awt.event.ComponentEvent e) { loadModules(); }
    });
}

/** Fills the table with the modules that match the year, semester and search box. */
private void loadModules() {
    String q = txtSearch.getText().trim().toLowerCase();
    int year = cmb_year.getSelectedIndex();   // 0 = ALL YEARS, 1..4
    int sem  = cmb_sem.getSelectedIndex();    // 0 = ALL SEMESTERS, 1..2

    DefaultTableModel m = (DefaultTableModel) tblModules.getModel();
    m.setRowCount(0);
    for (ModuleStore.ModuleData d : ModuleStore.all()) {
        if (year > 0 && d.getYearLevel() != year) continue;
        if (sem > 0 && d.getSemester() != sem) continue;

        String text = (d.getId() + " " + d.getName() + " " + d.getCode()).toLowerCase();
        if (!q.isEmpty() && !text.contains(q)) continue;

        m.addRow(new Object[]{d.getId(), d.getName(), d.getCode(), d.isAvailable() ? AVAILABLE : UNAVAILABLE});
    }
}

/** Saves every change made in the table (name, subject code, status). */
private void updateModules() {
    if (tblModules.isEditing()) tblModules.getCellEditor().stopCellEditing();   // finish typing first

    DefaultTableModel m = (DefaultTableModel) tblModules.getModel();
    for (int i = 0; i < m.getRowCount(); i++) {
        String id = String.valueOf(m.getValueAt(i, 0));
        String name = String.valueOf(m.getValueAt(i, 1)).trim();
        String code = String.valueOf(m.getValueAt(i, 2)).trim();
        boolean available = AVAILABLE.equals(m.getValueAt(i, 3));

        if (name.isEmpty() || code.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Module name and subject code can't be empty.",
                    "Module List", JOptionPane.WARNING_MESSAGE);
            loadModules();      // put the saved values back
            return;
        }
        ModuleStore.update(id, name, code, available);
    }
    JOptionPane.showMessageDialog(this, "Changes saved.", "Module List", JOptionPane.INFORMATION_MESSAGE);
}

/** Deletes the selected module after asking. */
private void deleteModule() {
    if (tblModules.isEditing()) tblModules.getCellEditor().cancelCellEditing();

    int row = tblModules.getSelectedRow();
    if (row < 0) {
        JOptionPane.showMessageDialog(this, "Select a module first.");
        return;
    }
    String id = String.valueOf(tblModules.getValueAt(row, 0));
    String name = String.valueOf(tblModules.getValueAt(row, 1));

    int ok = JOptionPane.showConfirmDialog(this, "Delete \"" + name + "\"?\nThis cannot be undone.",
            "Delete module", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
    if (ok != JOptionPane.YES_OPTION) return;

    ModuleStore.delete(id);
    loadModules();
}

public static void main(String[] args) {
    java.awt.EventQueue.invokeLater(() -> {
        javax.swing.JFrame f = new javax.swing.JFrame("Module List");
        f.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        f.setContentPane(new AdminModuleList_panel());
        f.setSize(1000, 560);
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    });
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlTop = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        cmb_sem = new javax.swing.JComboBox<>();
        cmb_year = new javax.swing.JComboBox<>();
        pnlBottom = new javax.swing.JPanel();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        scrollModules = new javax.swing.JScrollPane();
        tblModules = new javax.swing.JTable();

        setBackground(new java.awt.Color(22, 22, 22));
        setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 24, 24, 24));
        setLayout(new java.awt.BorderLayout());

        pnlTop.setBackground(new java.awt.Color(22, 22, 22));
        pnlTop.setPreferredSize(new java.awt.Dimension(0, 120));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(242, 242, 242));
        jLabel1.setText("Module List");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(168, 168, 168));
        jLabel2.setText("Manage modules");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(168, 168, 168));
        jLabel3.setText("Search module");

        txtSearch.setBackground(new java.awt.Color(26, 26, 26));
        txtSearch.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtSearch.setForeground(new java.awt.Color(242, 242, 242));
        txtSearch.setCaretColor(new java.awt.Color(242, 242, 242));

        cmb_sem.setBackground(new java.awt.Color(26, 26, 26));
        cmb_sem.setForeground(new java.awt.Color(242, 242, 242));
        cmb_sem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALL SEMESTERS", "1st Semester", "2nd Semester" }));

        cmb_year.setBackground(new java.awt.Color(26, 26, 26));
        cmb_year.setForeground(new java.awt.Color(242, 242, 242));
        cmb_year.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALL YEARS", "1st Year", "2nd Year", "3rd Year", "4th Year" }));

        javax.swing.GroupLayout pnlTopLayout = new javax.swing.GroupLayout(pnlTop);
        pnlTop.setLayout(pnlTopLayout);
        pnlTopLayout.setHorizontalGroup(
            pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTopLayout.createSequentialGroup()
                .addGroup(pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(0, 574, Short.MAX_VALUE))
            .addGroup(pnlTopLayout.createSequentialGroup()
                .addComponent(cmb_year, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cmb_sem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlTopLayout.setVerticalGroup(
            pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTopLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmb_year, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmb_sem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        add(pnlTop, java.awt.BorderLayout.NORTH);

        pnlBottom.setBackground(new java.awt.Color(22, 22, 22));
        pnlBottom.setPreferredSize(new java.awt.Dimension(0, 60));
        pnlBottom.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 5));

        btnUpdate.setBackground(new java.awt.Color(22, 22, 22));
        btnUpdate.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnUpdate.setForeground(new java.awt.Color(242, 242, 242));
        btnUpdate.setText("Update");
        btnUpdate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(58, 58, 58)));
        btnUpdate.setContentAreaFilled(false);
        btnUpdate.setFocusPainted(false);
        btnUpdate.setOpaque(true);
        btnUpdate.setPreferredSize(new java.awt.Dimension(110, 40));
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });
        pnlBottom.add(btnUpdate);

        btnDelete.setBackground(new java.awt.Color(22, 22, 22));
        btnDelete.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnDelete.setForeground(new java.awt.Color(240, 138, 151));
        btnDelete.setText("Delete");
        btnDelete.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(90, 42, 48)));
        btnDelete.setContentAreaFilled(false);
        btnDelete.setFocusPainted(false);
        btnDelete.setOpaque(true);
        btnDelete.setPreferredSize(new java.awt.Dimension(110, 40));
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        pnlBottom.add(btnDelete);

        add(pnlBottom, java.awt.BorderLayout.PAGE_END);

        scrollModules.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(58, 58, 58)));

        tblModules.setBackground(new java.awt.Color(32, 32, 32));
        tblModules.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tblModules.setForeground(new java.awt.Color(242, 242, 242));
        tblModules.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Module ID", "Module Name", "Subject Code", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblModules.setFillsViewportHeight(true);
        tblModules.setGridColor(new java.awt.Color(46, 46, 46));
        tblModules.setRowHeight(40);
        tblModules.setSelectionBackground(new java.awt.Color(44, 44, 44));
        tblModules.setSelectionForeground(new java.awt.Color(242, 242, 242));
        scrollModules.setViewportView(tblModules);

        add(scrollModules, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnDeleteActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> cmb_sem;
    private javax.swing.JComboBox<String> cmb_year;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel pnlBottom;
    private javax.swing.JPanel pnlTop;
    private javax.swing.JScrollPane scrollModules;
    private javax.swing.JTable tblModules;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
