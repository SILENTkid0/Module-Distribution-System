package moduledistributionsystem;

public class Student {
    private String studentId;
    private String lastName, firstName, course, section, password;

    public Student(String studentId, String lastName, String firstName,
                   String course, String section, String password) {
        this.studentId = studentId;
        setLastName(lastName);
        setFirstName(firstName);
        setCourse(course);
        setSection(section);
        this.password = password;
    }

    // getters
    public String getStudentId() { return studentId; }
    public String getLastName()  { return lastName; }
    public String getFirstName() { return firstName; }
    public String getCourse()    { return course; }
    public String getSection()   { return section; }
    public String getPassword()  { return password; }

    // setters with validation (the object protects its own data)
    public void setLastName(String v) {
        if (v == null || v.trim().isEmpty())
            throw new IllegalArgumentException("Last name is required");
        this.lastName = v.trim();
    }
    public void setFirstName(String v) {
        if (v == null || v.trim().isEmpty())
            throw new IllegalArgumentException("First name is required");
        this.firstName = v.trim();
    }
    public void setCourse(String v)  { this.course = v; }
    public void setSection(String v) { this.section = v; }
}