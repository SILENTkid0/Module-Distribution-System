package moduledistributionsystem;
 
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
 
 
 
public class ReserveModule_panel extends javax.swing.JPanel {
 
    /**
     * Creates new form RequestModule_panel
     */
    // ---------- colors, fonts, formats ----------
private static final Color CARD = new Color(0x202020), TEXT = new Color(0xF2F2F2), MUTED = new Color(0xA8A8A8);
private static final Color GREEN = new Color(0x4CD08A), GREEN_BG = new Color(0x1E3A2C);
private static final Color RED = new Color(0xF08A97), RED_BG = new Color(0x3F2327);
private static final Color BLUE = new Color(0x2F7FE0);
private static final Font F14 = new Font("Segoe UI", Font.PLAIN, 14);
private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH);
private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH);
 
private static class ModuleItem {
    final String code, name, year, sem;
    ModuleItem(String code, String name, String year, String sem) {
        this.code = code; this.name = name; this.year = year; this.sem = sem;
    }
}
 
public static void main(String[] args) {
    EventQueue.invokeLater(() -> {
        JFrame f = new JFrame("Reserve Module");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setContentPane(new ReserveModule_panel());
        f.setSize(1100, 720);
        f.setMinimumSize(new Dimension(900, 600));
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    });
}
/** Panel that stretches to the width of its scroll pane. */
private static class ScrollPanel extends JPanel implements Scrollable {
    @Override
    public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
    @Override
    public int getScrollableUnitIncrement(Rectangle r, int o, int d) { return 16; }
    @Override
    public int getScrollableBlockIncrement(Rectangle r, int o, int d) { return 64; }
    @Override
    public boolean getScrollableTracksViewportWidth() { return true; }
    @Override
    public boolean getScrollableTracksViewportHeight() { return false; }
}
 
// ---------- data and state ----------
private final List<ModuleItem> allModules = new ArrayList<>();
private final Map<String, ModuleItem> selected = new LinkedHashMap<>();
private java.util.Set<String> reservedCodes = new java.util.HashSet<>();   // modules this student already reserved/got

private final Set<LocalDate> closedDates = new HashSet<>();   // holidays / no-class days

 
private final ScrollPanel pnlModuleList = new ScrollPanel();
private final ScrollPanel pnlSlots = new ScrollPanel();
 
private LocalDate selectedDate;
private LocalTime selectedSlot;
 
public ReserveModule_panel() {
    initComponents();
    setupSearchHint();
    setupParts();
 
    setupCalendar();
    loadModules();
    refreshModules();
    refreshSelectedText();
    buildCalendar();
 
    cmbYear.addActionListener(e -> refreshModules());
    cmbSem.addActionListener(e -> refreshModules());
    txtSearch.getDocument().addDocumentListener(new DocumentListener() {
        @Override
        public void insertUpdate(DocumentEvent e)  { refreshModules(); }
        @Override
        public void removeUpdate(DocumentEvent e)  { refreshModules(); }
        @Override
        public void changedUpdate(DocumentEvent e) { refreshModules(); }
    });
    btnReserve.addActionListener(e -> submitRequest());
 
    addComponentListener(new ComponentAdapter() {
        @Override public void componentShown(ComponentEvent e) { refreshOnShow(); }
    });
}
 
private void setupParts() {
    pnlModuleList.setLayout(new BoxLayout(pnlModuleList, BoxLayout.Y_AXIS));
    pnlModuleList.setBackground(CARD);
    scrollModuleList.setViewportView(pnlModuleList);
    scrollModuleList.getViewport().setBackground(CARD);
 
    pnlSlots.setLayout(new GridLayout(0, 1, 0, 6));
    pnlSlots.setBackground(CARD);
    scrollSlots.setViewportView(pnlSlots);
    scrollSlots.getViewport().setBackground(CARD);
 
    // the main area follows the window width and scrolls when the window is short
    scrollMain.getVerticalScrollBar().setUnitIncrement(16);
    scrollMain.getViewport().addComponentListener(new ComponentAdapter() {
        @Override public void componentResized(ComponentEvent e) {
            Dimension vp = scrollMain.getViewport().getSize();
            pnlMain.setPreferredSize(new Dimension(vp.width, Math.max(700, vp.height)));
            pnlMain.revalidate();
        }
    });
}
 
// ---------- search box hint ----------
private static final String SEARCH_HINT = "Search module...";
private boolean showingHint;
 
private void setupSearchHint() {
    showHint();
    txtSearch.addFocusListener(new FocusAdapter() {
        @Override public void focusGained(FocusEvent e) {
            if (showingHint) {
                showingHint = false;
                txtSearch.setText("");
                txtSearch.setForeground(TEXT);
            }
        }
        @Override public void focusLost(FocusEvent e) {
            if (txtSearch.getText().trim().isEmpty()) showHint();
        }
    });
}
 
private void showHint() {
    showingHint = true;
    txtSearch.setForeground(new Color(0x7A7A7A));
    txtSearch.setText(SEARCH_HINT);
}
 
private String searchText() {
    return showingHint ? "" : txtSearch.getText().trim().toLowerCase();
}
 
// ---------- modules ----------
/** Loads the modules from the database (only the ones marked available). */
private void loadModules() {
    allModules.clear();
    for (ModuleStore.ModuleData d : ModuleStore.all()) {
        if (!d.isAvailable()) continue;
        String sem = d.getSemester() == 1 ? "1st Semester" : "2nd Semester";
        allModules.add(new ModuleItem(	d.getCode(), d.getName(), d.yearLabel(), sem));
    }
}

private void refreshModules() {
    pnlModuleList.removeAll();
    String year = String.valueOf(cmbYear.getSelectedItem());
    String sem = String.valueOf(cmbSem.getSelectedItem());
    String q = searchText();
 
    for (ModuleItem m : allModules) {
        if (!year.startsWith("ALL") && !m.year.equals(year)) continue;
        if (!sem.startsWith("ALL") && !m.sem.equals(sem)) continue;
        if (!q.isEmpty() && !(m.code + " " + m.name).toLowerCase().contains(q)) continue;
 
        boolean taken = reservedCodes.contains(m.code);
        JCheckBox cb = new JCheckBox(m.code + " - " + m.name + (taken ? "  (already reserved)" : ""),
                !taken && selected.containsKey(m.code));
        cb.setOpaque(false);
        cb.setFont(F14);
        cb.setForeground(taken ? MUTED : TEXT);
        cb.setEnabled(!taken);
        cb.setFocusPainted(false);
        cb.setAlignmentX(Component.LEFT_ALIGNMENT);
        cb.addActionListener(e -> {
            if (cb.isSelected()) selected.put(m.code, m); else selected.remove(m.code);
            refreshSelectedText();
        });
        pnlModuleList.add(cb);
    }
    pnlModuleList.revalidate();
    pnlModuleList.repaint();
}
 
private void refreshSelectedText() {
    StringBuilder sb = new StringBuilder();
    for (ModuleItem m : selected.values()) sb.append(m.code).append(" - ").append(m.name).append("\n");
    txtSelected.setText(sb.toString());
}
 
// ---------- calendar (JCalendar) ----------
private boolean isOpenDay(LocalDate d) {
    if (d.isBefore(LocalDate.now())) return false;
    DayOfWeek w = d.getDayOfWeek();
    if (w == DayOfWeek.SATURDAY || w == DayOfWeek.SUNDAY) return false;
    return !closedDates.contains(d);
}
 
private void setupCalendar() {
    calDate.setWeekOfYearVisible(false);
    calDate.setBackground(CARD);
    calDate.setDecorationBackgroundColor(CARD);
    calDate.setSundayForeground(MUTED);
    calDate.setWeekdayForeground(MUTED);
    calDate.getDayChooser().setBackground(CARD);
 
    calDate.getDayChooser().setAlwaysFireDayProperty(true);   // clicking the highlighted day still counts
    calDate.getDayChooser().addDateEvaluator(new AvailabilityEvaluator());
 
    calDate.getDayChooser().addPropertyChangeListener("day", e -> pickFromCalendar());
    calDate.getMonthChooser().addPropertyChangeListener("month", e -> pickFromCalendar());
    calDate.getYearChooser().addPropertyChangeListener("year", e -> pickFromCalendar());
}
 
/** Green = available, red = no distribution (weekend, holiday, past date). */
private class AvailabilityEvaluator implements com.toedter.calendar.IDateEvaluator {
    private LocalDate local(java.util.Date d) {
        return java.time.Instant.ofEpochMilli(d.getTime())
                .atZone(java.time.ZoneId.systemDefault()).toLocalDate();
    }
    @Override
    public boolean isSpecial(java.util.Date date) { return isOpenDay(local(date)); }
    @Override
    public boolean isInvalid(java.util.Date date) { return !isOpenDay(local(date)); }
 
    @Override
    public Color getSpecialForegroundColor() { return GREEN; }
    @Override
    public Color getSpecialBackroundColor()  { return GREEN_BG; }
    @Override
    public String getSpecialTooltip()        { return "Distribution available"; }
 
    @Override
    public Color getInvalidForegroundColor() { return RED; }
    @Override
    public Color getInvalidBackroundColor()  { return RED_BG; }
    @Override
    public String getInvalidTooltip()        { return "No distribution"; }
}
 
/** Reads the day highlighted in the calendar and updates the slots and summary. */
private void pickFromCalendar() {
    LocalDate d = LocalDate.of(calDate.getYearChooser().getYear(),
            calDate.getMonthChooser().getMonth() + 1,      // month chooser is 0-based
            calDate.getDayChooser().getDay());
    selectedDate = isOpenDay(d) ? d : null;
    selectedSlot = null;
    buildSlots();
    updateSummary();
}
 
private void buildCalendar() {          // jump back to today
    calDate.setDate(new java.util.Date());
    pickFromCalendar();
}
 
private void refreshOnShow() {
    loadModules();
    reservedCodes = ReservationStore.reservedModuleCodes(ReservationStore.currentStudentId);
    selected.keySet().removeAll(reservedCodes);
    refreshModules();
    YearMonth shown = YearMonth.of(calDate.getYearChooser().getYear(),
            calDate.getMonthChooser().getMonth() + 1);
    boolean newMonth = shown.isBefore(YearMonth.now());
    boolean datePassed = selectedDate != null && selectedDate.isBefore(LocalDate.now());
    if (newMonth || datePassed) {
        buildCalendar();
    } else {
        buildSlots();
        updateSummary();
    }
}
 
// ---------- time slots ----------
private List<LocalTime> slotStarts() {
    List<LocalTime> list = new ArrayList<>();
    for (LocalTime t = LocalTime.of(8, 0); t.isBefore(LocalTime.of(12, 0)); t = t.plusMinutes(30)) list.add(t);
    for (LocalTime t = LocalTime.of(13, 30); t.isBefore(LocalTime.of(17, 0)); t = t.plusMinutes(30)) list.add(t);
    return list;
}
 
private String range(LocalTime start) {
    return start.format(TIME_FMT) + " - " + start.plusMinutes(30).format(TIME_FMT);
}
 
private boolean isFull(LocalDate date, LocalTime start) {
    if (date.equals(LocalDate.now()) && !start.isAfter(LocalTime.now())) return true;   // already passed
    return ReservationStore.isSlotFull(date, start);
}
 
private void flat(JButton b, Color bg, Color fg) {
    b.setBackground(bg);
    b.setForeground(fg);
    b.setOpaque(true);
    b.setContentAreaFilled(false);
    b.setBorderPainted(false);
    b.setFocusPainted(false);
}
 
private void buildSlots() {
    pnlSlots.removeAll();
    if (selectedDate == null) {
        JLabel hint = new JLabel("Pick a distribution date first");
        hint.setFont(F14);
        hint.setForeground(MUTED);
        pnlSlots.add(hint);
    } else {
        for (LocalTime start : slotStarts()) {
            boolean full = isFull(selectedDate, start);
            JButton b = new JButton(range(start) + (full ? "    Full" : ""));
            b.setFont(F14);
            b.setHorizontalAlignment(SwingConstants.LEFT);
            b.setMargin(new Insets(6, 12, 6, 12));
            if (full) flat(b, RED_BG, RED);
            else if (start.equals(selectedSlot)) flat(b, BLUE, Color.WHITE);
            else flat(b, GREEN_BG, GREEN);
            if (!full) {
                b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                b.addActionListener(e -> { selectedSlot = start; buildSlots(); updateSummary(); });
            }
            pnlSlots.add(b);
        }
    }
    pnlSlots.revalidate();
    pnlSlots.repaint();
}
 
// ---------- summary and submit ----------
private void updateSummary() {
    lblDateValue.setText("Date: " + (selectedDate == null ? "-" : selectedDate.format(DATE_FMT)));
    lblTimeValue.setText("Time: " + (selectedSlot == null ? "-" : range(selectedSlot)));
}
 
private void submitRequest() {
    if (selected.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please select at least one module.", "Reserve Module", JOptionPane.WARNING_MESSAGE);
        return;
    }
    if (selectedDate == null || selectedSlot == null) {
        JOptionPane.showMessageDialog(this, "Please choose a distribution date and a time slot.", "Reserve Module", JOptionPane.WARNING_MESSAGE);
        return;
    }
 
    java.util.Set<String> codes = new java.util.LinkedHashSet<>();
    java.util.Set<String> years = new java.util.LinkedHashSet<>();
    java.util.Set<String> sems = new java.util.LinkedHashSet<>();
    for (ModuleItem m : selected.values()) { codes.add(m.code); years.add(m.year); sems.add(m.sem); }
 
    // ---- cannot reserve a module you already reserved / got ----
    java.util.Set<String> already = ReservationStore.reservedModuleCodes(ReservationStore.currentStudentId);
    StringBuilder dup = new StringBuilder();
    for (ModuleItem m : selected.values()) {
        if (already.contains(m.code)) dup.append("\n").append(m.code).append(" - ").append(m.name);
    }
    if (dup.length() > 0) {
        JOptionPane.showMessageDialog(this,
                "You already reserved/received these module(s):" + dup
                + "\n\nPlease remove them from your selection.",
                "Reserve Module", JOptionPane.WARNING_MESSAGE);
        reservedCodes = already;
        selected.keySet().removeAll(already);
        refreshModules();
        refreshSelectedText();
        return;
    }

    // ---- ask for confirmation BEFORE saving anything ----
    String summary = "Please confirm your reservation:\n\n" + txtSelected.getText()
            + "\n\n" + lblDateValue.getText() + "\n" + lblTimeValue.getText()
            + "\n\nDo you want to reserve these modules?";
    int choice = JOptionPane.showConfirmDialog(this, summary, "Confirm Reservation",
            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
    // Only an explicit YES continues. NO or the X button (CLOSED_OPTION) cancels.
    if (choice != JOptionPane.YES_OPTION) {
        return;
    }

    ReservationStore.Reservation r = ReservationStore.add(ReservationStore.currentStudentId,
            String.join(", ", years), String.join(", ", sems), String.join(", ", codes),
            selectedDate.format(DATE_FMT), range(selectedSlot));

    if (r == null) {
        JOptionPane.showMessageDialog(this,
                "Sorry, that time slot is already full (or the reservation could not be saved).\nPlease pick another slot.",
                "Reserve Module", JOptionPane.WARNING_MESSAGE);
        buildCalendar();
        return;
    }

    JOptionPane.showMessageDialog(this, "Reservation confirmed!  (" + r.getId() + ")\n\n" + txtSelected.getText()
            + "\n" + lblDateValue.getText() + "\n" + lblTimeValue.getText(),
            "Reserve Module", JOptionPane.INFORMATION_MESSAGE);

    selected.clear();
    reservedCodes = ReservationStore.reservedModuleCodes(ReservationStore.currentStudentId);
    refreshModules();
    refreshSelectedText();
    buildCalendar();
}
 
 
    // Variables declaration - do not modify                     

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlTop = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        scrollMain = new javax.swing.JScrollPane();
        pnlMain = new javax.swing.JPanel();
        pnlPick = new javax.swing.JPanel();
        pnlFilters = new javax.swing.JPanel();
        txtSearch = new javax.swing.JTextField();
        pnlCombos = new javax.swing.JPanel();
        cmbYear = new javax.swing.JComboBox<>();
        cmbSem = new javax.swing.JComboBox<>();
        pnlModuleBox = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        scrollModuleList = new javax.swing.JScrollPane();
        pnlBand2 = new javax.swing.JPanel();
        pnlDate = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        calDate = new com.toedter.calendar.JCalendar();
        jLabel5 = new javax.swing.JLabel();
        pnlTime = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        scrollSlots = new javax.swing.JScrollPane();
        pnlRight = new javax.swing.JPanel();
        pnlSelected = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        scrollSelected = new javax.swing.JScrollPane();
        txtSelected = new javax.swing.JTextArea();
        pnlSummary = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lblDateValue = new javax.swing.JLabel();
        lblTimeValue = new javax.swing.JLabel();
        btnReserve = new javax.swing.JButton();

        setBackground(new java.awt.Color(22, 22, 22));
        setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 24, 24, 24));
        setLayout(new java.awt.BorderLayout());

        pnlTop.setBackground(new java.awt.Color(22, 22, 22));
        pnlTop.setPreferredSize(new java.awt.Dimension(0, 70));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(242, 242, 242));
        jLabel1.setText("Reserve Module");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(168, 168, 168));
        jLabel2.setText("Choose your modules, then pick a distribution date and a time slot");

        javax.swing.GroupLayout pnlTopLayout = new javax.swing.GroupLayout(pnlTop);
        pnlTop.setLayout(pnlTopLayout);
        pnlTopLayout.setHorizontalGroup(
            pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTopLayout.createSequentialGroup()
                .addGroup(pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGap(0, 686, Short.MAX_VALUE))
        );
        pnlTopLayout.setVerticalGroup(
            pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTopLayout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(0, 19, Short.MAX_VALUE))
        );

        add(pnlTop, java.awt.BorderLayout.NORTH);

        scrollMain.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        scrollMain.setHorizontalScrollBar(null);

        pnlMain.setBackground(new java.awt.Color(22, 22, 22));
        pnlMain.setForeground(new java.awt.Color(242, 242, 242));
        pnlMain.setLayout(new java.awt.BorderLayout());

        pnlPick.setBackground(new java.awt.Color(32, 32, 32));
        pnlPick.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(58, 58, 58)), javax.swing.BorderFactory.createEmptyBorder(12, 14, 12, 14)));
        pnlPick.setPreferredSize(new java.awt.Dimension(0, 230));
        pnlPick.setLayout(new java.awt.BorderLayout());

        pnlFilters.setBackground(new java.awt.Color(32, 32, 32));
        pnlFilters.setPreferredSize(new java.awt.Dimension(0, 40));
        pnlFilters.setLayout(new java.awt.BorderLayout(10, 0));

        txtSearch.setBackground(new java.awt.Color(26, 26, 26));
        txtSearch.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtSearch.setForeground(new java.awt.Color(242, 242, 242));
        txtSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSearchActionPerformed(evt);
            }
        });
        pnlFilters.add(txtSearch, java.awt.BorderLayout.CENTER);

        pnlCombos.setBackground(new java.awt.Color(32, 32, 32));
        pnlCombos.setPreferredSize(new java.awt.Dimension(310, 0));
        pnlCombos.setLayout(new java.awt.GridLayout(1, 2, 10, 0));

        cmbYear.setBackground(new java.awt.Color(26, 26, 26));
        cmbYear.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cmbYear.setForeground(new java.awt.Color(242, 242, 242));
        cmbYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALL YEARS", "1st Year", "2nd Year", "3rd Year", "4th Year" }));
        pnlCombos.add(cmbYear);

        cmbSem.setBackground(new java.awt.Color(26, 26, 26));
        cmbSem.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cmbSem.setForeground(new java.awt.Color(242, 242, 242));
        cmbSem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALL SEMESTERS", "1st Semester", "2nd Semester" }));
        pnlCombos.add(cmbSem);

        pnlFilters.add(pnlCombos, java.awt.BorderLayout.WEST);

        pnlPick.add(pnlFilters, java.awt.BorderLayout.NORTH);

        pnlModuleBox.setBackground(new java.awt.Color(32, 32, 32));
        pnlModuleBox.setLayout(new java.awt.BorderLayout());

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(242, 242, 242));
        jLabel3.setText("Select Modules");
        pnlModuleBox.add(jLabel3, java.awt.BorderLayout.NORTH);
        pnlModuleBox.add(scrollModuleList, java.awt.BorderLayout.CENTER);

        pnlPick.add(pnlModuleBox, java.awt.BorderLayout.CENTER);

        pnlMain.add(pnlPick, java.awt.BorderLayout.NORTH);

        pnlBand2.setBackground(new java.awt.Color(22, 22, 22));
        pnlBand2.setForeground(new java.awt.Color(242, 242, 242));
        pnlBand2.setMinimumSize(new java.awt.Dimension(0, 0));
        pnlBand2.setPreferredSize(new java.awt.Dimension(663, 300));
        pnlBand2.setLayout(new java.awt.GridLayout(1, 3, 16, 0));

        pnlDate.setBackground(new java.awt.Color(32, 32, 32));
        pnlDate.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(58, 58, 58)), javax.swing.BorderFactory.createEmptyBorder(12, 14, 12, 14)));
        pnlDate.setLayout(new java.awt.BorderLayout());

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(242, 242, 242));
        jLabel4.setText("Select Distribution Date");
        pnlDate.add(jLabel4, java.awt.BorderLayout.NORTH);
        pnlDate.add(calDate, java.awt.BorderLayout.CENTER);

        jLabel5.setText("<html><font color='#4CD08A'>●</font> Available &nbsp;&nbsp; <font color='#F08A97'>●</font> No distribution</html>");
        pnlDate.add(jLabel5, java.awt.BorderLayout.SOUTH);

        pnlBand2.add(pnlDate);

        pnlTime.setBackground(new java.awt.Color(32, 32, 32));
        pnlTime.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(58, 58, 58)), javax.swing.BorderFactory.createEmptyBorder(12, 14, 12, 14)));
        pnlTime.setLayout(new java.awt.BorderLayout());

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(242, 242, 242));
        jLabel6.setText("Select time slot");
        pnlTime.add(jLabel6, java.awt.BorderLayout.NORTH);
        pnlTime.add(scrollSlots, java.awt.BorderLayout.CENTER);

        pnlBand2.add(pnlTime);

        pnlRight.setBackground(new java.awt.Color(22, 22, 22));
        pnlRight.setForeground(new java.awt.Color(242, 242, 242));
        pnlRight.setLayout(new java.awt.GridLayout(2, 1, 0, 16));

        pnlSelected.setBackground(new java.awt.Color(32, 32, 32));
        pnlSelected.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(58, 58, 58)), javax.swing.BorderFactory.createEmptyBorder(12, 14, 12, 14)));
        pnlSelected.setLayout(new java.awt.BorderLayout());

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(242, 242, 242));
        jLabel7.setText("Selected Modules");
        pnlSelected.add(jLabel7, java.awt.BorderLayout.NORTH);

        txtSelected.setEditable(false);
        txtSelected.setBackground(new java.awt.Color(26, 26, 26));
        txtSelected.setColumns(20);
        txtSelected.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtSelected.setForeground(new java.awt.Color(242, 242, 242));
        txtSelected.setLineWrap(true);
        txtSelected.setRows(5);
        txtSelected.setWrapStyleWord(true);
        scrollSelected.setViewportView(txtSelected);

        pnlSelected.add(scrollSelected, java.awt.BorderLayout.CENTER);

        pnlRight.add(pnlSelected);

        pnlSummary.setBackground(new java.awt.Color(32, 32, 32));
        pnlSummary.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(58, 58, 58)), javax.swing.BorderFactory.createEmptyBorder(12, 14, 12, 14)));
        pnlSummary.setLayout(new java.awt.BorderLayout());

        jLabel8.setForeground(new java.awt.Color(242, 242, 242));
        jLabel8.setText("Selected Date & Time");
        pnlSummary.add(jLabel8, java.awt.BorderLayout.NORTH);

        jPanel1.setBackground(new java.awt.Color(22, 22, 22));

        lblDateValue.setForeground(new java.awt.Color(242, 242, 242));
        lblDateValue.setText("Date: -");

        lblTimeValue.setForeground(new java.awt.Color(242, 242, 242));
        lblTimeValue.setText("Time: -");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDateValue)
                    .addComponent(lblTimeValue))
                .addContainerGap(267, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblDateValue)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTimeValue)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        pnlSummary.add(jPanel1, java.awt.BorderLayout.CENTER);

        btnReserve.setBackground(new java.awt.Color(47, 127, 224));
        btnReserve.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnReserve.setForeground(new java.awt.Color(255, 255, 255));
        btnReserve.setText("Reserve");
        btnReserve.setBorderPainted(false);
        btnReserve.setPreferredSize(new java.awt.Dimension(0, 43));
        pnlSummary.add(btnReserve, java.awt.BorderLayout.SOUTH);

        pnlRight.add(pnlSummary);

        pnlBand2.add(pnlRight);

        pnlMain.add(pnlBand2, java.awt.BorderLayout.CENTER);

        scrollMain.setViewportView(pnlMain);

        add(scrollMain, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSearchActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnReserve;
    private com.toedter.calendar.JCalendar calDate;
    private javax.swing.JComboBox<String> cmbSem;
    private javax.swing.JComboBox<String> cmbYear;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblDateValue;
    private javax.swing.JLabel lblTimeValue;
    private javax.swing.JPanel pnlBand2;
    private javax.swing.JPanel pnlCombos;
    private javax.swing.JPanel pnlDate;
    private javax.swing.JPanel pnlFilters;
    private javax.swing.JPanel pnlMain;
    private javax.swing.JPanel pnlModuleBox;
    private javax.swing.JPanel pnlPick;
    private javax.swing.JPanel pnlRight;
    private javax.swing.JPanel pnlSelected;
    private javax.swing.JPanel pnlSummary;
    private javax.swing.JPanel pnlTime;
    private javax.swing.JPanel pnlTop;
    private javax.swing.JScrollPane scrollMain;
    private javax.swing.JScrollPane scrollModuleList;
    private javax.swing.JScrollPane scrollSelected;
    private javax.swing.JScrollPane scrollSlots;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextArea txtSelected;
    // End of variables declaration//GEN-END:variables
}
