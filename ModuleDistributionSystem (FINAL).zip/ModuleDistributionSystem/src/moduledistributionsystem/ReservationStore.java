package moduledistributionsystem;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Reservations, stored in `reservations` + `reservation_items` (read through
 * the view v_reservations).
 */
public class ReservationStore {

    // names kept so the other screens still compile; values are what the database stores
    public static final String UPCOMING = "Pending", COLLECTED = "Acquired", MISSED = "Missed";

    /**
     * A time slot is full when this many reservations already use it.
     */
    public static final int SLOT_CAPACITY = 25;

    /**
     * Student ID of whoever is logged in. Set it when the student logs in.
     */
    public static String currentStudentId;

    public static class Reservation {

        private static final DateTimeFormatter D = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH);
        private static final DateTimeFormatter T = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH);

        private final String id, studentId, year, sem, modules, date, time;
        private String status;
        private boolean reminded;

        public String getId() {
            return id;
        }

        public String getStudentId() {
            return studentId;
        }

        public String getYear() {
            return year;
        }

        public String getSem() {
            return sem;
        }

        public String getModules() {
            return modules;
        }

        public String getDate() {
            return date;
        }

        public String getTime() {
            return time;
        }

        public String getStatus() {
            return status;
        }

        public boolean isReminded() {
            return reminded;
        }

        public void setStatus(String status) {
            if (!status.equals("Pending") && !status.equals("Acquired") && !status.equals("Missed")) {
                throw new IllegalArgumentException("Invalid status: " + status);
            }
            this.status = status;
        }

        public void setReminded(boolean reminded) {
            this.reminded = reminded;
        }

        public Reservation(String id, String studentId, String year, String sem,
                String modules, String date, String time, String status) {
            this.id = id;
            this.studentId = studentId;
            this.year = year;
            this.sem = sem;
            this.modules = modules;
            this.date = date;
            this.time = time;
            this.status = status;
        }

        public LocalDateTime startTime() {
            LocalDate d = LocalDate.parse(date, D);
            LocalTime t = LocalTime.parse(time.split(" - ")[0].trim(), T);
            return LocalDateTime.of(d, t);
        }

        public LocalDateTime endTime() {
            LocalDate d = LocalDate.parse(date, D);
            LocalTime t = LocalTime.parse(time.split(" - ")[1].trim(), T);
            return LocalDateTime.of(d, t);
        }
    }

    // ---------- helpers ----------
    private static final String SELECT
            = "SELECT reservation_id, student_id, year_levels, semesters, reserved_modules, "
            + "distribution_date, slot_start, slot_end, status, reminded FROM v_reservations ";

    private static String toId(int n) {
        return String.format("RSV-%04d", n);
    }

    private static int parseId(String id) {
        return Integer.parseInt(id.replaceAll("\\D", ""));
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private static Reservation read(ResultSet rs) throws SQLException {
        LocalTime s = rs.getTime("slot_start").toLocalTime();
        LocalTime e = rs.getTime("slot_end").toLocalTime();
        Reservation r = new Reservation(
                toId(rs.getInt("reservation_id")),
                rs.getString("student_id"),
                nz(rs.getString("year_levels")),
                nz(rs.getString("semesters")),
                nz(rs.getString("reserved_modules")),
                rs.getDate("distribution_date").toLocalDate().format(Reservation.D),
                s.format(Reservation.T) + " - " + e.format(Reservation.T),
                rs.getString("status"));
        r.reminded = rs.getBoolean("reminded");
        return r;
    }

    private static List<Reservation> query(String where, String param) {
        List<Reservation> list = new ArrayList<>();
        String sql = SELECT + where + " ORDER BY reservation_id DESC";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            if (param != null) {
                ps.setString(1, param);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(read(rs));
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return list;
    }

    // ---------- reading ----------
    /**
     * One student's reservations, newest first.
     */
    public static List<Reservation> forStudent(String studentId) {
        return query("WHERE student_id = ?", studentId);
    }

    /**
     * Everyone's reservations (for the admin screen), newest first.
     */
    public static List<Reservation> all() {
        return query("", null);
    }

    public static Reservation find(String id) {
        List<Reservation> l = query("WHERE reservation_id = ?", String.valueOf(parseId(id)));
        return l.isEmpty() ? null : l.get(0);
    }

    /**
     * How many reservations already use this date + slot start.
     */
    public static int countForSlot(LocalDate date, LocalTime slotStart) {
        try (Connection con = DBConnection.getConnection()) {
            return countForSlot(con, date, slotStart);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    public static boolean isSlotFull(LocalDate date, LocalTime slotStart) {
        return countForSlot(date, slotStart) >= SLOT_CAPACITY;
    }

    private static int countForSlot(Connection con, LocalDate date, LocalTime slotStart) throws SQLException {
        String sql = "SELECT COUNT(*) FROM reservations WHERE distribution_date = ? AND slot_start = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, java.sql.Date.valueOf(date));
            ps.setTime(2, Time.valueOf(slotStart));
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    // ---------- booking rules ----------
    /**
     * Subject codes this student already has in a Pending or Acquired
     * reservation. They cannot reserve these again (Missed ones can be retried).
     */
    public static java.util.Set<String> reservedModuleCodes(String studentId) {
        java.util.Set<String> codes = new java.util.HashSet<>();
        if (studentId == null) {
            return codes;
        }
        try (Connection con = DBConnection.getConnection()) {
            codes.addAll(reservedModuleCodes(con, studentId));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return codes;
    }

    private static java.util.Set<String> reservedModuleCodes(Connection con, String studentId) throws SQLException {
        java.util.Set<String> codes = new java.util.HashSet<>();
        String sql = "SELECT DISTINCT m.subject_code FROM reservations r "
                + "JOIN reservation_items ri ON ri.reservation_id = r.reservation_id "
                + "JOIN modules m ON m.module_id = ri.module_id "
                + "WHERE r.student_id = ? AND r.status IN (?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, studentId);
            ps.setString(2, UPCOMING);
            ps.setString(3, COLLECTED);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    codes.add(rs.getString(1));
                }
            }
        }
        return codes;
    }

    // ---------- writing ----------
    /**
     * Saves a reservation. Same arguments as before: modules = subject codes
     * joined by ", ", date = "October 9, 2026", time = "8:00 AM - 8:30 AM".
     * (year / sem are not stored, they come from the modules themselves.)
     * Returns null if the slot is already full or the save failed -- check for
     * null.
     */
    public static Reservation add(String studentId, String year, String sem,
            String modules, String date, String time) {
        try (Connection con = DBConnection.getConnection()) {
            LocalDate d = LocalDate.parse(date, Reservation.D);
            LocalTime start = LocalTime.parse(time.split(" - ")[0].trim(), Reservation.T);
            LocalTime end = LocalTime.parse(time.split(" - ")[1].trim(), Reservation.T);

            con.setAutoCommit(false);
            try {
                for (String code : modules.split(",")) {      // no repeat modules
                    if (reservedModuleCodes(con, studentId).contains(code.trim())) {
                        con.rollback();
                        return null;
                    }
                }
                if (countForSlot(con, d, start) >= SLOT_CAPACITY) {
                    con.rollback();
                    return null;
                }

                int id;
                String ins = "INSERT INTO reservations (student_id, distribution_date, slot_start, slot_end) "
                        + "VALUES (?,?,?,?)";
                try (PreparedStatement ps = con.prepareStatement(ins, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, studentId);
                    ps.setDate(2, java.sql.Date.valueOf(d));
                    ps.setTime(3, Time.valueOf(start));
                    ps.setTime(4, Time.valueOf(end));
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        keys.next();
                        id = keys.getInt(1);
                    }
                }

                String item = "INSERT IGNORE INTO reservation_items (reservation_id, module_id) "
                        + "SELECT ?, module_id FROM modules WHERE subject_code = ?";
                try (PreparedStatement ps = con.prepareStatement(item)) {
                    for (String code : modules.split(",")) {
                        ps.setInt(1, id);
                        ps.setString(2, code.trim());
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }

                con.commit();
                Reservation saved = find(toId(id));      // read back so year / sem match the database
                return saved != null ? saved
                        : new Reservation(toId(id), studentId, year, sem, modules, date, time, UPCOMING);
            } catch (Exception ex) {
                con.rollback();
                throw ex;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    /**
     * Admin action: Pending -> Acquired / Missed. Only Pending reservations can
     * change. Also sends the student a notification. Returns true if the status
     * changed.
     */
    public static boolean setStatus(String id, String status) {
        return setStatus(id, status, LocalDateTime.now());
    }

    /**
     * Same, with the time to show on the notification.
     */
    public static boolean setStatus(String id, String status, LocalDateTime when) {
        String sql = "UPDATE reservations SET status = ? WHERE reservation_id = ? AND status = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, parseId(id));
            ps.setString(3, UPCOMING);
            if (ps.executeUpdate() == 0) {
                return false;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }

        Reservation r = find(id);
        if (r != null) {
            if (COLLECTED.equals(status)) {
                NotificationStore.add(r.studentId, NotificationStore.ACQUIRED,
                        "Module acquired", "You have received your module.", when);
            } else if (MISSED.equals(status)) {
                NotificationStore.add(r.studentId, NotificationStore.MISSED,
                        "Reservation missed", "You have missed your reservation.", when);
            }
        }
        return true;
    }

    /**
     * Marks the pickup reminder as sent. True only the first time (so it is
     * sent once).
     */
    public static boolean markReminded(String id) {
        String sql = "UPDATE reservations SET reminded = 1 WHERE reservation_id = ? AND reminded = 0";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, parseId(id));
            return ps.executeUpdate() > 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
