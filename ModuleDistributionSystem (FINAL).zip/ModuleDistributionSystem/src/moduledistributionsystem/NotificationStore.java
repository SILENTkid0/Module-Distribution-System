package moduledistributionsystem;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/** Notifications, stored in the MySQL table `notifications` (one student sees only their own). */
public class NotificationStore {

    public static final String REMINDER = "reminder", MISSED = "missed", ACQUIRED = "acquired";

    public static class Note {
        public final String studentId, type, title, message;
        public final LocalDateTime time;
        public Note(String studentId, String type, String title, String message, LocalDateTime time) {
            this.studentId = studentId; this.type = type; this.title = title;
            this.message = message; this.time = time;
        }
    }

    public static void add(String studentId, String type, String title, String message, LocalDateTime time) {
        String sql = "INSERT INTO notifications (student_id, type, title, message, created_at) VALUES (?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, studentId);
            ps.setString(2, type);
            ps.setString(3, title);
            ps.setString(4, message);
            ps.setTimestamp(5, Timestamp.valueOf(time));
            ps.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /** Newest first. */
    public static List<Note> forStudent(String studentId) {
        List<Note> list = new ArrayList<>();
        String sql = "SELECT type, title, message, created_at FROM notifications "
                   + "WHERE student_id = ? ORDER BY created_at DESC, notification_id DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Note(studentId, rs.getString("type"), rs.getString("title"),
                            rs.getString("message"), rs.getTimestamp("created_at").toLocalDateTime()));
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return list;
    }

    /**
     * Run when the student opens Notifications (or My Reservation):
     *  - 5 minutes before the slot starts -> "Time to pick up your modules"
     *  - slot ended and still Pending -> Missed + "Reservation missed"
     * Both are saved in the database, so nothing is sent twice.
     */
    public static void checkReservations(String studentId) {
        LocalDateTime now = LocalDateTime.now();
        for (ReservationStore.Reservation r : ReservationStore.forStudent(studentId)) {
            if (!r.getStatus().equals(ReservationStore.UPCOMING)) continue;

            if (now.isAfter(r.endTime())) {
                // setStatus also creates the "missed" notification
                ReservationStore.setStatus(r.getId(), ReservationStore.MISSED, r.endTime());
            } else if (!r.isReminded() && !now.isBefore(r.startTime().minusMinutes(5))) {
                if (ReservationStore.markReminded(r.getId())) {
                    add(studentId, REMINDER, "Time to pick up your modules",
                            "Go get your module in Main South Campus basement.",
                            r.startTime().minusMinutes(5));
                }
            }
        }
    }
}